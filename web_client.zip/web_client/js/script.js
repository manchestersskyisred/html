document.addEventListener("DOMContentLoaded", () => {
    const showInfoButton = document.getElementById("show-info");
    const questionnaireButton = document.getElementById("questionnaire");
    const consultButton = document.getElementById("consult");

    // 跳转到心理网站信息页面
    showInfoButton.addEventListener("click", () => {
        window.location.href = "https://your-psychology-website.com"; // 替换为心理网站的实际 URL
    });

    // 跳转到心理问卷页面
    questionnaireButton.addEventListener("click", () => {
        window.location.href = "https://www.wjx.cn/vm/rXSknpy.aspx";
    });

    // 跳转到进一步咨询页面
    consultButton.addEventListener("click", () => {
        window.location.href = "https://www.smhc.org.cn/";
    });
});